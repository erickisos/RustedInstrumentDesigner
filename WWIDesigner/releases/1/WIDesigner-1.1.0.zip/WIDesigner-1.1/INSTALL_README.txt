Installation README

This is an upgrade distribution for WIDesigner and
requires a full install.

Please read UPGRADE_README for installation instructions.