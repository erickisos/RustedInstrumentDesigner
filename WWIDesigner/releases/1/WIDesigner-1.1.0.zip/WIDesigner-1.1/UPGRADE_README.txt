Upgrading a release

This release is an upgrade. It requires a full download and will
create a new WIDesigner directory. An upgrade is typically made
when the supporting library files have changed. Nonetheless, all
of the files (instrument, tuning, and constraints) that you have
used or made with other 1.x releases are fully compatible with this
release.

Download WIDesigner-1.x.0. Follow the instructions in the YouTube:
   http://youtu.be/nDlKJURdHfw

If you normally keep your working files in the installation
directory, you might want to copy them to the directory you just
created with this new release.

And if you are on a UNIX/Linux system, perform the
steps in the UNIX_README file.