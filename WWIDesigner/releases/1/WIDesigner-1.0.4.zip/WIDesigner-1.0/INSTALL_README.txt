Installation README

If this is the first time you have installed WIDesigner,
download WIDesigner-1.x.x. Follow the instructions in
the YouTube:
   http://youtu.be/nDlKJURdHfw
   
If you have installed a prior version of WIDesigner,
please follow the instructions in UPDATE_README.txt.