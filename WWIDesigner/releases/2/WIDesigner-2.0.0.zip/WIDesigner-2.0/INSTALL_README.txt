Installation README

This is a major-version upgrade distribution for WIDesigner and
requires a full install. Such an upgrade is typically made
when the supporting library files have changed and there are
incompatibilities with the prior version. However, all
of the files (instrument, tuning, and constraints) that you have
used or made with 1.0.3 or later releases are fully compatible with this
release.

Download WIDesigner-2.0.0. Follow the instructions in the YouTube:
   http://youtu.be/nDlKJURdHfw

If you normally keep your working files in the installation
directory, you might want to copy them to the directory you just
created with this new release.

And if you are on a UNIX/Linux system, perform the
steps in the UNIX_README file.